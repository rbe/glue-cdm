package com.bensmann.cdm.acct

/**
 * 
 */
class AccountingService {
	
	/**
	 * Create an AcctOffer with values from Offer.
	 */
	def createOffer(Offer offer) {
	}
	
	/**
	 * Create an AcctOrder with values from Order.
	 */
	def createOrder(Order order) {
	}
	
	/**
	 * Create an AcctInvoice with values from Invoice.
	 */
	def createInvoice(Invoice invoice) {
	}
	
}
